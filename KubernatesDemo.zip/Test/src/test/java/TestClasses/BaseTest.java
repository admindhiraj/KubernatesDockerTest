package TestClasses;
import java.io.File;
import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import Pages.Pojo;
import Pages.Utility;
import Pages.wrapperFunction;

public class BaseTest extends Pojo{

	private wrapperFunction objwrapperFunction;
	private WebDriver driver;
	private Utility objUtility;
	private Properties objProperties;
	
	public void intializeEnviroment() throws MalformedURLException {
		
		
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		//driver = new RemoteWebDriver(new URL("http://192.168.99.100:4444/"), capabilities);
//		capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR,
//                UnexpectedAlertBehaviour.IGNORE);
		//System.setProperty("webdriver.chrome.driver",".\\src\\main\\resources\\chromedriver.exe");
		driver = new RemoteWebDriver(new URL("http://192.168.99.100:4444/wd/hub"),capabilities);     //Used for docker
		//driver = new RemoteWebDriver(new URL("http://192.168.99.100:32399/wd/hub"),capabilities); 		//used for 
		//WebDriver driver=new ChromeDriver(capabilities);
		
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login");
		//driver.manage().window().maximize();
		this.setObjWebdriver(driver);
		
		objwrapperFunction=new wrapperFunction(this);
		this.setObjwrapperFunction(objwrapperFunction);
		
		objUtility=new Utility(this);
		this.setObjUtility(objUtility);
		
		objProperties =this.loadPropertyFile();
		this.setObjProperties(objProperties);
	}
	
	public void tearDownEnviroment(){
		driver.quit();
	}
	
	public Properties loadPropertyFile() {
		File src = new File(System.getProperty("user.dir")+"\\src\\main\\resources\\config.properties");
		
		try {
			FileInputStream fis = new FileInputStream(src);
			objProperties = new Properties();
			objProperties.load(fis);
		} catch (Exception e) {
			System.out.println("Exception is " + e.getMessage());
		}
		return objProperties;
	}
}
