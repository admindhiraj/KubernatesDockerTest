package TestClasses;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.Utility;
import Pages.emmployeeInFormationPage;
import Pages.loginPage;

public class PracticeTest extends BaseTest{
	
	private loginPage objloginPage;
	private emmployeeInFormationPage objemmployeeInFormationPage;
	private Utility objUtility;
	
	@BeforeTest
	public void intialiseEnvioroment() throws MalformedURLException {
		intializeEnviroment();
		objloginPage = new loginPage(this);
		objemmployeeInFormationPage = new emmployeeInFormationPage(this);
		objUtility = new Utility(this);
	}
	
	@Test
	public void test() throws IOException, InterruptedException {
		
		List<String> list=objUtility.getFilesinFolder();
		int size=list.size();
		System.out.println("@@@@@@@ Size "+size);
		if(size>0){
			String destDirectory=objUtility.createDestinationFolder();
			for(int i=0;i<size;i++){
				Thread.sleep(1500);
				objUtility.copyFile(destDirectory,list.get(i));
				objUtility.deleteFile(list.get(i));
				Thread.sleep(1000);
			}
		}else{
			System.out.println("@@@@@ No files are present in folder @@@@@");
		}
		
	}
	
	@Test
	public void test_1() throws IOException, InterruptedException {
		//Login 
		objloginPage.setUserName("Admin");
		objloginPage.setPassword("admin123");
		objloginPage.clickOnLoginButton();
		
		//Save Employee Details
		objemmployeeInFormationPage.clickOnPIMTab();
		objemmployeeInFormationPage.clickOnAddEmplyeeTab();
		objemmployeeInFormationPage.inpFirstNameEmployee("Test");
		objemmployeeInFormationPage.inpLastNameEmployee("Test");
		String str= objemmployeeInFormationPage.getEmployeeID();
		System.out.println("@@@@@@@@@@@@"+str);
	}

	@AfterTest
	public void tearDownEnvioroment() {
		tearDownEnviroment();
		objloginPage = null;
		objemmployeeInFormationPage = null;
	}
}
