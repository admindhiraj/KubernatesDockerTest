package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class employeeListPage {
	
private Pojo objPojo;
	
	public employeeListPage(Pojo objPojo) {
		this.objPojo=objPojo;
	}
	
	By lnkEmployeeList=By.xpath("//a[@id='menu_pim_viewEmployeeList']");
	
	public void clickOnEmployeeListTab() {
		objPojo.getObjwrapperFunction().click(lnkEmployeeList);
	}
	
	public void verifyEmployeeAdded(String str) {
		By locator=By.xpath("//table[@id='resultTable']//a[text()='"+str+"']");
		objPojo.getObjwrapperFunction().waitTillElementDisplyed(locator);
	}
	
	public void getPrevioiusRowData(String str) {
		By id=By.xpath("//table[@id='resultTable']//a[text()='"+str+"']//parent::td//parent::tr/preceding::tr[1]/td[2]/a");
		String id1=objPojo.getObjwrapperFunction().getText(id);
		System.out.println("@@@@@@@Previous id= "+id1);
		
		By name=By.xpath("//table[@id='resultTable']//a[text()='"+str+"']//parent::td//parent::tr/preceding::tr[1]/td[3]/a");
		String name1=objPojo.getObjwrapperFunction().getText(name);
		System.out.println("@@@@@@@Previous name= "+name1);
		
		By lastname=By.xpath("//table[@id='resultTable']//a[text()='"+str+"']//parent::td//parent::tr/preceding::tr[1]/td[4]/a");
		String lastname1=objPojo.getObjwrapperFunction().getText(lastname);
		System.out.println("@@@@@@@Previous lastname= "+lastname1);
	}
	
	public void getFollowingRowData(String str) {
		By id=By.xpath("//table[@id='resultTable']//a[text()='"+str+"']//parent::td//parent::tr/following::tr[1]/td[2]/a");
		String id1=objPojo.getObjwrapperFunction().getText(id);
		System.out.println("@@@@@@@Following id= "+id1);
		
		By name=By.xpath("//table[@id='resultTable']//a[text()='"+str+"']//parent::td//parent::tr/following::tr[1]/td[3]/a");
		String name1=objPojo.getObjwrapperFunction().getText(name);
		System.out.println("@@@@@@@Following name= "+name1);
		
		By lastname=By.xpath("//table[@id='resultTable']//a[text()='"+str+"']//parent::td//parent::tr/following::tr[1]/td[4]/a");
		String lastname1=objPojo.getObjwrapperFunction().getText(lastname);
		System.out.println("@@@@@@@Following lastname= "+lastname1);
	}
	
}
