package Pages;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Utility {
	
	private Pojo objPojo;
	
	public Utility(Pojo objPojo) {
		this.objPojo=objPojo;
	}
	
	public static FileInputStream fis;
	public static FileOutputStream fos;
	public static XSSFWorkbook wb;
	public static XSSFSheet sheet;
	public static XSSFRow row;
	public static XSSFCell cell;
	
	
	public static List<String> getRowData(String xlsxFileName,String xlsheet,int rownum)  
	{
		List<String> list = new ArrayList<String>();
		try{
		fis=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\"+xlsxFileName+".xlsx");
		wb=new XSSFWorkbook(fis);
		sheet=wb.getSheet(xlsheet);
		row=sheet.getRow(0);
		
		int cellcount=row.getLastCellNum();
		for (int i = 0; i < cellcount; i++) {
		try 
		{
			DataFormatter formatter = new DataFormatter();
            String cellData = formatter.formatCellValue(sheet.getRow(rownum).getCell(i));
            list.add(cellData);
		}
		catch (Exception e) 
		{
			list.add(null);
		}}
			
		wb.close();
		fis.close();
			}catch(Exception e){
				e.printStackTrace();
		}
		return list;
	}
	
	public static void setCellData(String xlsxFileName,String xlsheet,int rownum,int colnum,String data) throws IOException
	{
		fis=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\"+xlsxFileName+".xlsx");
		wb=new XSSFWorkbook(fis);
		sheet=wb.getSheet(xlsheet);
		row=sheet.getRow(rownum);
		cell=row.createCell(colnum);
		cell.setCellValue(data);
		fos=new FileOutputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\"+xlsxFileName+".xlsx");
		wb.write(fos);		
		wb.close();
		fis.close();
		fos.close();
	}
	
	public static int getRowCount(String xlsxFileName,String xlsheet) throws IOException
	{
		fis=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\"+xlsxFileName+".xlsx");
		wb=new XSSFWorkbook(fis);
		sheet=wb.getSheet(xlsheet);
		int rowcount=sheet.getLastRowNum();
		wb.close();
		fis.close();
		return rowcount;		
	}
	
	public String createDestinationFolder() throws IOException{
		//String timeStamp = new SimpleDateFormat("dd MMMM yyyy-HH.mm.ss").format(new Date());
		//String destDirectory=objPojo.getObjProperties().getProperty("DestinationFilePath")+timeStamp;

		String destDirectory=objPojo.getObjProperties().getProperty("DestinationFilePath");
		File destDir = new File(destDirectory);
        if (!destDir.exists()) {
            destDir.mkdir();
        }
        objPojo.getObjwrapperFunction().waitForTime(1000);
        return destDirectory;
	 }
	
	public void copyFile(String destDirectory,String filename) throws IOException{
      String sourceFilePath=objPojo.getObjProperties().getProperty("SourceFilePath")+filename;
      String destinationFilePath=destDirectory+"\\"+filename;
      File source = new File(sourceFilePath);
      File destination = new File(destinationFilePath);
      FileUtils.copyFile(source, destination);
      objPojo.getObjwrapperFunction().waitForTime(2000);
	}
	
	public void deleteFile(String filename) throws IOException{
	  String sourceFilePath=objPojo.getObjProperties().getProperty("SourceFilePath")+filename;
      File destination = new File(sourceFilePath);
      destination.delete();
      objPojo.getObjwrapperFunction().waitForTime(2000);
	}
	
	public List<String> getFilesinFolder() throws IOException{
		 List<String> list = new ArrayList<String>();
		 File directory=new File(objPojo.getObjProperties().getProperty("SourceFilePath")); 
		 String[] filesinFolder = directory.list();
		 	if (filesinFolder == null) {
		 		System.out.println("Either files does not exist or is not a directory"); 
		 		list.add(null);
		 	} else { 
		 			for (int i = 0; i< filesinFolder.length; i++) {
		 				String filename = filesinFolder[i];
		 				list.add(filename);
		 			} 
		 	}
		 	return list;
	} 
}
