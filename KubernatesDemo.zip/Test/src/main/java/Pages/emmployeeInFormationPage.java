package Pages;
import org.openqa.selenium.By;

public class emmployeeInFormationPage {
	
	private Pojo objPojo;
	
	public emmployeeInFormationPage(Pojo objPojo) {
		this.objPojo=objPojo;
	}
	
	By lnkPIM=By.xpath("//a[@id='menu_pim_viewPimModule']");
	By lnkAddEmployee=By.xpath("//a[@id='menu_pim_addEmployee']");
	By inpFirstName=By.xpath("//input[@id='firstName']");
	By inpLastName=By.xpath("//input[@id='lastName']");
	By btnSave=By.xpath("//input[@id='btnSave']");
	By lblEmployeeID=By.xpath("//input[@id='employeeId']");
	
	
	public void clickOnPIMTab() {
		objPojo.getObjwrapperFunction().click(lnkPIM);
	}
	
	public void clickOnAddEmplyeeTab() {
		objPojo.getObjwrapperFunction().click(lnkAddEmployee);
	}
	
	public void inpFirstNameEmployee(String str) {
		objPojo.getObjwrapperFunction().setText(inpFirstName, str);
	}
	
	public void inpLastNameEmployee(String str) {
		objPojo.getObjwrapperFunction().setText(inpLastName, str);
	}
	
	public void clickOnSaveEmplyeeButton() {
		objPojo.getObjwrapperFunction().click(btnSave);
	}
	
	public String getEmployeeID() {
		String str=objPojo.getObjwrapperFunction().getAttribute(lblEmployeeID, "value");
		return str;
	}
	
}
