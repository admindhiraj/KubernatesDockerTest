package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class wrapperFunction {

	private Pojo objPojo;
	
	public wrapperFunction(Pojo objPojo) {
		this.objPojo=objPojo;
	}
	
	public void waitForTime(int timeDuration){
		try {
			Thread.sleep(timeDuration);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void waitTillElementClickable(By locator) {
		WebDriverWait wait=new WebDriverWait(objPojo.getObjWebdriver(),10);
		wait.until(ExpectedConditions.elementToBeClickable(locator));
	}
	
	public void setText(By locator,String str) {
		this.waitTillElementClickable(locator);
		objPojo.getObjWebdriver().findElement(locator).sendKeys(str);
	}
	
	public void click(By locator) {
		this.waitTillElementClickable(locator);
		objPojo.getObjWebdriver().findElement(locator).click();
	}
	
	public String getAttribute(By locator,String attribute) {
		//this.waitTillElementClickable(locator);
		String str=objPojo.getObjWebdriver().findElement(locator).getAttribute(attribute);
		return str;
	}
	
	public String getText(By locator) {
		this.waitTillElementDisplyed(locator);
		String str= objPojo.getObjWebdriver().findElement(locator).getText();
		return str;
	}
	
	public void waitTillElementDisplyed(By locator) {
		WebDriverWait wait=new WebDriverWait(objPojo.getObjWebdriver(),10);
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}
}
