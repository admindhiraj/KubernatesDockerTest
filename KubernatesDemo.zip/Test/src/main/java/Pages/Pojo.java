package Pages;
import java.util.Properties;

import org.openqa.selenium.WebDriver;


public class Pojo {
	private WebDriver objWebdriver;
	private wrapperFunction objwrapperFunction;
	private Utility objUtility;
	private Properties objProperties;
	
	public WebDriver getObjWebdriver() {
		return objWebdriver;
	}
	public void setObjWebdriver(WebDriver objWebdriver) {
		this.objWebdriver = objWebdriver;
	}
	public wrapperFunction getObjwrapperFunction() {
		return objwrapperFunction;
	}
	public void setObjwrapperFunction(wrapperFunction objwrapperFunction) {
		this.objwrapperFunction = objwrapperFunction;
	}
	public Utility getObjUtility() {
		return objUtility;
	}
	public void setObjUtility(Utility objUtility) {
		this.objUtility = objUtility;
	}
	public Properties getObjProperties() {
		return objProperties;
	}
	public void setObjProperties(Properties objProperties) {
		this.objProperties = objProperties;
	}
}
