package Pages;
import org.openqa.selenium.By;

public class loginPage {

private Pojo objPojo;
	
	public loginPage(Pojo objPojo) {
		this.objPojo=objPojo;
	}
	
	By userName=By.xpath("//input[@id='txtUsername']");
	By password=By.xpath("//input[@id='txtPassword']");
	By btnLogin=By.xpath("//input[@id='btnLogin']");
	
	public void setUserName(String str) {
		objPojo.getObjwrapperFunction().setText(userName, str);
	}
	
	public void setPassword(String str) {
		objPojo.getObjwrapperFunction().setText(password, str);
	}
	
	public void clickOnLoginButton() {
		objPojo.getObjwrapperFunction().click(btnLogin);
	}
	
}
